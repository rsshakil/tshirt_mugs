<?php
	$types = $params['types'];
	$types[] = 'psd';
	$types[] = 'pdf';
	$types[] = 'ai';
	$GLOBALS['types'] = $types;
?>