<div class="modal" id="dg-product-detail" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="row">
		<div class="col-md-8 col-sm-8 col-xs-12 product-images">
			<div class="product-thumbs"></div>
			<div class="product-main-img"></div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12 g-product-options"></div>
	</div>
</div>