<div id="dialog-update-photo" title="<?php echo lang('designer_upload_repace'); ?>">
	<p><?php echo lang('designer_upload_repace_des'); ?></p>
</div>
<script type="text/javascript">
	lang.text.add_new = '<?php echo lang('designer_add_new'); ?>';
	lang.text.replace = '<?php echo lang('designer_replace'); ?>';
</script>