<?php
/**
 * @author tshirtecommerce - www.tshirtecommerce.com
 * @date: 2015-01-10
 * 
 * API
 * 
 * @copyright  Copyright (C) 2015 tshirtecommerce.com. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 *
 */
$addons = $GLOBALS['addons'];
?>
<div class="col-xs-1 col-sm-1 col-md-1">
	<a href="javascript:void(0)" onclick="design.share.google()" class="icon-25" title="<?php echo $addons->__('addon_share_google_plus_title'); ?>"><img class="img-responsive" src="<?php echo $addons->base_url; ?>addons/images/google.png" alt="<?php echo $addons->__('addon_share_google_plus_title'); ?>"></a> 
</div>