<?php
$addons = $GLOBALS['addons'];
?>
<button class="btn btn-default btn-boder" type="button" data-type="filter" onclick="showSvgTxtFilterPop()">
	<i class="fa fa-filter"></i> <small><?php echo $addons->__('addon_textpattern_buttonlabel_en'); ?></small>
</button>