<?php
$addons = $GLOBALS['addons'];
?>
<li data-type="arc">
	<i class="glyph-icon flaticon-vector"></i> <small class="clearfix"><?php echo $addons->__('addon_text_arc_title'); ?></small>
</li>