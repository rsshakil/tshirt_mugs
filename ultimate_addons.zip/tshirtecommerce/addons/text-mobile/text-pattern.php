<?php
$addons = $GLOBALS['addons'];
?>
<li data-type="filter" onclick="showSvgTxtFilterPop()">
	<i class="fa fa-filter"></i> 
	<small class="clearfix"><?php echo $addons->__('addon_textpattern_buttonlabel_en'); ?></small>
</li>