<?php
$settings 	= $GLOBALS['settings'];
$dg 		= $GLOBALS['dg'];
$dg->view('modal_store', 'editor');
?>